Ebadsave VSLA Backup & Restore patch

Files included:
- App.tsx (navigation includes BackupRestore route)
- src/database/database.ts (existing database, safe restore validation, meeting-specific verified backup receipts)
- src/screens/HomeScreen.tsx (visible Backup & Restore entry; based on the latest saved HomeScreen_fixed(2).tsx)
- src/screens/NewMeetingScreen.tsx (fresh verified backup is created immediately before closing; cash must also balance)
- src/screens/BackupRestoreScreen.tsx (backup/export/restore UI)
- src/utils/backupFiles.ts (backup file save/share/read helpers)

Install Expo-compatible dependencies in the existing project:
  npx expo install expo-file-system expo-document-picker expo-sharing

Then copy the included files to the matching locations in the existing project.
Do not delete the SQLite database or uninstall the app to apply this patch.

Android meeting-close behaviour:
- Checking cash first applies automatic meeting activity fines idempotently, then calculates reconciliation.
- When the user chooses “Backup & End Meeting”, a fresh JSON snapshot is made immediately before closure.
- The user must select a device folder. The external copy is written and read back for verification.
- Only after verification does SQLite record a meeting-specific backup receipt.
- The database closeMeeting function checks for that receipt; passing a boolean alone is not enough.
- If folder selection, writing, verification, receipt recording, or cash reconciliation fails, the meeting remains open.

Restore behaviour:
- User selects a JSON file.
- Required backup sections and allowed column names are validated before any table is deleted.
- User confirms that restore replaces local records.
- Restore and financial-account repair run inside a SQLite transaction.
- Backup receipts are not imported across devices; an open meeting must be backed up again on the restoring device before it can be closed.
- Legacy version-1 backups missing only the new meeting_backup_receipts section remain restorable.

Validation performed for this patch: TypeScript/TSX syntax transpilation only. A complete Expo Android build and device test could not be run because the full project package.json, app config, and node_modules were not provided in this working environment.
