import { Platform } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { createDatabaseBackup, createMeetingClosureBackup, recordVerifiedMeetingBackup } from '../database/database';

export type SavedBackup = {
  filename: string;
  createdAt: string;
  localUri: string;
  externalUri: string;
};

function makeBackupFilename(date = new Date()): string {
  const stamp = date.toISOString().replace(/[:.]/g, '-');
  return `Ebadsave_VSLA_Backup_${stamp}.json`;
}

/**
 * Creates a complete SQLite JSON snapshot, keeps a private app copy, and on
 * Android requires the user to save a second copy into a selected folder.
 * If folder selection or writing fails, this function rejects so a meeting
 * cannot be closed on the strength of an internal temporary copy alone.
 */
export async function createAndSaveBackupToDevice(options: { meetingId?: number } = {}): Promise<SavedBackup> {
  const backupJson = options.meetingId !== undefined
    ? await createMeetingClosureBackup(options.meetingId)
    : await createDatabaseBackup();
  const createdAt = new Date().toISOString();
  const filename = makeBackupFilename(new Date(createdAt));

  if (!FileSystem.documentDirectory) {
    throw new Error('The app storage directory is unavailable. No backup was confirmed.');
  }

  const localUri = `${FileSystem.documentDirectory}${filename}`;
  await FileSystem.writeAsStringAsync(localUri, backupJson, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  const localInfo = await FileSystem.getInfoAsync(localUri);
  if (!localInfo.exists || !('size' in localInfo) || localInfo.size <= 0) {
    throw new Error('The backup file could not be verified after writing.');
  }

  let externalUri = localUri;
  if (Platform.OS === 'android') {
    const saf = FileSystem.StorageAccessFramework;
    if (!saf) {
      throw new Error('Android folder access is unavailable. Install the compatible Expo FileSystem package and try again.');
    }

    const permission = await saf.requestDirectoryPermissionsAsync();
    if (!permission.granted || !permission.directoryUri) {
      throw new Error('You cancelled folder selection. The meeting remains open because an external backup was not confirmed.');
    }

    externalUri = await saf.createFileAsync(
      permission.directoryUri,
      filename,
      'application/json',
    );
    await FileSystem.writeAsStringAsync(externalUri, backupJson, {
      encoding: FileSystem.EncodingType.UTF8,
    });

    const verified = await FileSystem.readAsStringAsync(externalUri, {
      encoding: FileSystem.EncodingType.UTF8,
    });
    if (verified !== backupJson) {
      throw new Error('The saved backup did not pass verification. The meeting remains open.');
    }
  } else {
    // On iOS, create a durable app copy and open the system share sheet so the
    // user can save it to Files or another backup destination.
    const sharingAvailable = await Sharing.isAvailableAsync();
    if (!sharingAvailable) {
      throw new Error('The backup was created inside the app, but sharing is unavailable. Save/export it before closing the meeting.');
    }
    await Sharing.shareAsync(localUri, {
      mimeType: 'application/json',
      dialogTitle: 'Save Ebadsave VSLA backup',
      UTI: 'public.json',
    });
  }

  if (options.meetingId !== undefined) {
    // The database will refuse to close this meeting without this exact receipt.
    await recordVerifiedMeetingBackup(options.meetingId, createdAt, filename, externalUri);
  }

  return { filename, createdAt, localUri, externalUri };
}

export async function shareSavedBackup(localUri: string): Promise<void> {
  const info = await FileSystem.getInfoAsync(localUri);
  if (!info.exists) throw new Error('The saved backup file is no longer available. Create a new backup first.');
  if (!(await Sharing.isAvailableAsync())) throw new Error('Sharing is not available on this device.');
  await Sharing.shareAsync(localUri, {
    mimeType: 'application/json',
    dialogTitle: 'Share Ebadsave VSLA backup',
    UTI: 'public.json',
  });
}

export async function readPickedBackup(uri: string): Promise<string> {
  const content = await FileSystem.readAsStringAsync(uri, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (!content.trim()) throw new Error('The selected backup file is empty.');
  return content;
}
