import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import {
  restoreDatabaseBackup,
  validateDatabaseBackup,
} from '../database/database';
import {
  createAndSaveBackupToDevice,
  readPickedBackup,
  shareSavedBackup,
} from '../utils/backupFiles';

type Props = { navigation: any };

export default function BackupRestoreScreen({ navigation }: Props) {
  const [busy, setBusy] = useState(false);
  const [lastBackupUri, setLastBackupUri] = useState('');
  const [lastBackupName, setLastBackupName] = useState('');
  const [status, setStatus] = useState('Create a backup before closing a meeting.');

  const createBackup = async () => {
    try {
      setBusy(true);
      setStatus('Preparing a complete database backup…');
      const saved = await createAndSaveBackupToDevice();
      setLastBackupUri(saved.localUri);
      setLastBackupName(saved.filename);
      setStatus(`Backup saved and verified: ${saved.filename}`);
      Alert.alert(
        'Backup Successful',
        `Your Ebadsave VSLA backup was saved and verified.\n\nFile: ${saved.filename}\n\nKeep a copy somewhere safe.`,
      );
    } catch (error) {
      setStatus('Backup was not confirmed. Existing database records were not deleted.');
      Alert.alert(
        'Backup Not Completed',
        error instanceof Error ? error.message : 'The backup could not be created.',
      );
    } finally {
      setBusy(false);
    }
  };

  const shareBackup = async () => {
    if (!lastBackupUri) {
      Alert.alert('No Backup Selected', 'Create a backup first.');
      return;
    }
    try {
      setBusy(true);
      await shareSavedBackup(lastBackupUri);
    } catch (error) {
      Alert.alert('Unable to Share Backup', error instanceof Error ? error.message : 'The backup could not be shared.');
    } finally {
      setBusy(false);
    }
  };

  const chooseRestoreFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/json', 'text/json', 'text/plain', 'application/octet-stream'],
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (result.canceled || !result.assets?.length) return;
      const selected = result.assets[0];

      // Validate the complete file before asking the user to confirm the
      // destructive restore operation.
      const contents = await readPickedBackup(selected.uri);
      const parsed = validateDatabaseBackup(contents);
      const tableCount = Object.keys(parsed.tables).length;

      Alert.alert(
        'Replace Local Database?',
        `Restore backup created ${parsed.created_at || 'at an unknown time'}?\n\nThis replaces the groups, members, meetings and financial records currently stored on this device with the selected backup (${tableCount} data sections). Create and keep a current backup first.`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Restore Database',
            style: 'destructive',
            onPress: () => {
              void (async () => {
                try {
                  setBusy(true);
                  await restoreDatabaseBackup(contents);
                  setStatus(`Restore completed from ${selected.name}.`);
                  Alert.alert(
                    'Restore Successful',
                    'The backup was restored. Return to authorization to reload the app from the restored local data.',
                    [{ text: 'Continue', onPress: () => navigation.navigate('PreAppAuthorization') }],
                  );
                } catch (error) {
                  Alert.alert('Restore Failed', error instanceof Error ? error.message : 'The backup could not be restored.');
                } finally {
                  setBusy(false);
                }
              })();
            },
          },
        ],
      );
    } catch (error) {
      Alert.alert(
        'Invalid Backup',
        error instanceof Error ? error.message : 'The selected file is not a valid Ebadsave backup.',
      );
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Text style={styles.backText}>‹ Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Backup & Restore</Text>
          <Text style={styles.subtitle}>Protect groups, members, meetings and financial records.</Text>
        </View>

        <View style={styles.noticeCard}>
          <Text style={styles.noticeTitle}>Important</Text>
          <Text style={styles.noticeText}>
            Save backups to a folder you can find again, such as Downloads or a trusted cloud-drive folder. Restoring replaces the local database on this device. It does not merge two databases.
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Create Backup</Text>
          <Text style={styles.description}>
            Creates a JSON snapshot of the local database. On Android, select a folder and the app verifies the saved file before reporting success.
          </Text>
          <TouchableOpacity style={[styles.primaryButton, busy && styles.disabled]} onPress={() => void createBackup()} disabled={busy}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryButtonText}>Create & Save Backup</Text>}
          </TouchableOpacity>
          {!!lastBackupName && <Text style={styles.savedFile}>Last backup: {lastBackupName}</Text>}
          {!!lastBackupUri && (
            <TouchableOpacity style={styles.secondaryButton} onPress={() => void shareBackup()} disabled={busy}>
              <Text style={styles.secondaryButtonText}>Share Last Backup</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Restore Backup</Text>
          <Text style={styles.description}>
            Choose a previously saved Ebadsave JSON backup. The app checks that all required data sections are present before it allows restoration.
          </Text>
          <TouchableOpacity style={[styles.restoreButton, busy && styles.disabled]} onPress={() => void chooseRestoreFile()} disabled={busy}>
            <Text style={styles.primaryButtonText}>Choose Backup File & Restore</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.statusCard}>
          <Text style={styles.statusHeading}>Status</Text>
          <Text style={styles.statusText}>{status}</Text>
        </View>

        <TouchableOpacity style={styles.footerButton} onPress={() => navigation.goBack()} disabled={busy}>
          <Text style={styles.footerButtonText}>Return to App</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16, paddingBottom: 36 },
  header: { backgroundColor: '#16a34a', borderRadius: 14, padding: 18, marginBottom: 14 },
  backButton: { alignSelf: 'flex-start', paddingVertical: 4, marginBottom: 8 },
  backText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  title: { color: '#fff', fontSize: 25, fontWeight: '800' },
  subtitle: { color: '#dcfce7', marginTop: 6, fontSize: 14, lineHeight: 20 },
  noticeCard: { borderWidth: 1, borderColor: '#fcd34d', borderRadius: 12, backgroundColor: '#fffbeb', padding: 14, marginBottom: 14 },
  noticeTitle: { color: '#92400e', fontWeight: '800', fontSize: 15, marginBottom: 5 },
  noticeText: { color: '#78350f', fontSize: 13, lineHeight: 19 },
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 14, borderWidth: 1, borderColor: '#e5e7eb' },
  sectionTitle: { color: '#111827', fontSize: 18, fontWeight: '800' },
  description: { color: '#4b5563', fontSize: 14, lineHeight: 20, marginTop: 8 },
  primaryButton: { backgroundColor: '#16a34a', borderRadius: 10, paddingVertical: 14, alignItems: 'center', marginTop: 14 },
  restoreButton: { backgroundColor: '#b91c1c', borderRadius: 10, paddingVertical: 14, alignItems: 'center', marginTop: 14 },
  primaryButtonText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  secondaryButton: { borderWidth: 1, borderColor: '#16a34a', borderRadius: 10, paddingVertical: 12, alignItems: 'center', marginTop: 10 },
  secondaryButtonText: { color: '#16a34a', fontSize: 14, fontWeight: '800' },
  savedFile: { color: '#166534', fontSize: 12, marginTop: 10, lineHeight: 17 },
  disabled: { opacity: 0.55 },
  statusCard: { backgroundColor: '#f0fdf4', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#bbf7d0' },
  statusHeading: { color: '#166534', fontWeight: '800', fontSize: 14, marginBottom: 5 },
  statusText: { color: '#166534', fontSize: 13, lineHeight: 19 },
  footerButton: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 10, paddingVertical: 13, alignItems: 'center', marginTop: 14 },
  footerButtonText: { color: '#374151', fontSize: 15, fontWeight: '700' },
});
