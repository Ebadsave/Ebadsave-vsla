import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { RootStackParamList } from '../../App';
import {
  getGroupById,
  getMeetingRollCall,
  isMeetingRollCallComplete,
  recordMeetingAttendance,
} from '../database/database';

type Props = NativeStackScreenProps<RootStackParamList, 'RollCall'>;

type Attendance = {
  id: number;
  meeting_id: number;
  group_id: number;
  member_id: number;
  member_number: string;
  full_name: string;
  attendance_status: string;
  marked_at: string | null;
  marked_by: number | null;
  notes: string;
};

export default function RollCallScreen({ route, navigation }: Props) {
  const { groupId, meetingId, executiveMemberId } = route.params;

  const [groupName, setGroupName] = useState('');
  const [members, setMembers] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingMemberId, setSavingMemberId] = useState<number | null>(null);
  const [complete, setComplete] = useState(false);

  const loadRollCall = useCallback(async () => {
    try {
      setLoading(true);

      const group = await getGroupById(groupId);
      setGroupName(group?.group_name ?? 'Ebadsave VSLA Group');

      const rows = await getMeetingRollCall(meetingId);
      setMembers(rows);
      setComplete(await isMeetingRollCallComplete(meetingId));
    } catch (error) {
      Alert.alert(
        'Unable to Load Roll Call',
        error instanceof Error ? error.message : 'Roll call could not be loaded.',
      );
    } finally {
      setLoading(false);
    }
  }, [groupId, meetingId]);

  useEffect(() => {
    loadRollCall();
  }, [loadRollCall]);

  const counts = useMemo(() => {
    return {
      present: members.filter((m) => m.attendance_status === 'present').length,
      late: members.filter((m) => m.attendance_status === 'late').length,
      absent: members.filter((m) => m.attendance_status === 'absent').length,
      pending: members.filter((m) => m.attendance_status === 'pending').length,
    };
  }, [members]);

  const markAttendance = async (
    memberId: number,
    status: 'present' | 'late' | 'absent',
  ) => {
    try {
      setSavingMemberId(memberId);

      await recordMeetingAttendance(
        meetingId,
        memberId,
        status,
        executiveMemberId,
      );

      const rows = await getMeetingRollCall(meetingId);
      setMembers(rows);
      setComplete(await isMeetingRollCallComplete(meetingId));
    } catch (error) {
      Alert.alert(
        'Unable to Save Attendance',
        error instanceof Error ? error.message : 'Attendance could not be saved.',
      );
    } finally {
      setSavingMemberId(null);
    }
  };

  const continueToSavings = () => {
    if (!complete) {
      Alert.alert(
        'Roll Call Incomplete',
        'Mark every active member as Present, Late, or Absent before continuing.',
      );
      return;
    }

    navigation.navigate(
      'Savings' as never,
      { groupId, meetingId, executiveMemberId } as never,
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#16a34a" />
          <Text style={styles.loadingText}>Loading roll call...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Meeting Roll Call</Text>
          <Text style={styles.groupName}>{groupName}</Text>
          <Text style={styles.meetingText}>Meeting #{meetingId}</Text>
        </View>

        <View style={styles.summaryCard}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryNumber}>{members.length}</Text>
            <Text style={styles.summaryLabel}>Members</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.presentNumber}>{counts.present}</Text>
            <Text style={styles.summaryLabel}>Present</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.lateNumber}>{counts.late}</Text>
            <Text style={styles.summaryLabel}>Late</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.absentNumber}>{counts.absent}</Text>
            <Text style={styles.summaryLabel}>Absent</Text>
          </View>
        </View>

        <Text style={styles.instruction}>
          Mark every active member before moving to savings. A member can still save when absent; attendance is used for meeting records and loan eligibility.
        </Text>

        {members.map((member) => {
          const busy = savingMemberId === member.member_id;
          const status = member.attendance_status;

          return (
            <View key={member.member_id} style={styles.memberCard}>
              <View style={styles.memberInfo}>
                <Text style={styles.memberName}>{member.full_name}</Text>
                <Text style={styles.memberNumber}>{member.member_number}</Text>
                <Text style={styles.currentStatus}>
                  Status: {status.toUpperCase()}
                </Text>
              </View>

              <View style={styles.actionsRow}>
                <TouchableOpacity
                  style={[styles.actionButton, styles.presentButton]}
                  onPress={() => markAttendance(member.member_id, 'present')}
                  disabled={busy}
                >
                  <Text style={styles.actionText}>PRESENT</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.actionButton, styles.lateButton]}
                  onPress={() => markAttendance(member.member_id, 'late')}
                  disabled={busy}
                >
                  <Text style={styles.actionText}>LATE</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.actionButton, styles.absentButton]}
                  onPress={() => markAttendance(member.member_id, 'absent')}
                  disabled={busy}
                >
                  <Text style={styles.actionText}>ABSENT</Text>
                </TouchableOpacity>
              </View>

              {busy && <ActivityIndicator color="#16a34a" style={styles.rowLoader} />}
            </View>
          );
        })}

        <View style={complete ? styles.completeBox : styles.pendingBox}>
          <Text style={complete ? styles.completeText : styles.pendingText}>
            {complete
              ? '✓ Roll call complete. The meeting can continue to savings.'
              : `${counts.pending} member(s) still need attendance marked.`}
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.continueButton, !complete && styles.disabledButton]}
          onPress={continueToSavings}
          disabled={!complete}
        >
          <Text style={styles.continueText}>CONTINUE TO SAVINGS</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backText}>BACK</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ffffff' },
  content: { padding: 18, paddingBottom: 40 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { marginTop: 10, color: '#374151' },
  header: { marginBottom: 16 },
  title: { fontSize: 28, fontWeight: '800', color: '#16a34a' },
  groupName: { marginTop: 4, fontSize: 17, color: '#111827', fontWeight: '700' },
  meetingText: { marginTop: 3, color: '#6b7280' },
  summaryCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#f0fdf4',
    borderWidth: 1,
    borderColor: '#bbf7d0',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  summaryItem: { alignItems: 'center', flex: 1 },
  summaryNumber: { fontSize: 20, fontWeight: '800', color: '#111827' },
  presentNumber: { fontSize: 20, fontWeight: '800', color: '#16a34a' },
  lateNumber: { fontSize: 20, fontWeight: '800', color: '#b45309' },
  absentNumber: { fontSize: 20, fontWeight: '800', color: '#dc2626' },
  summaryLabel: { marginTop: 2, fontSize: 11, color: '#6b7280' },
  instruction: { color: '#4b5563', fontSize: 13, lineHeight: 19, marginBottom: 14 },
  memberCard: {
    borderWidth: 1,
    borderColor: '#e5e7eb',
    borderRadius: 11,
    padding: 13,
    marginBottom: 10,
    backgroundColor: '#ffffff',
  },
  memberInfo: { marginBottom: 10 },
  memberName: { fontSize: 16, fontWeight: '800', color: '#111827' },
  memberNumber: { marginTop: 2, fontSize: 12, color: '#6b7280' },
  currentStatus: { marginTop: 5, fontSize: 11, fontWeight: '700', color: '#16a34a' },
  actionsRow: { flexDirection: 'row', gap: 7 },
  actionButton: { flex: 1, borderRadius: 7, paddingVertical: 10, alignItems: 'center' },
  presentButton: { backgroundColor: '#16a34a' },
  lateButton: { backgroundColor: '#d97706' },
  absentButton: { backgroundColor: '#dc2626' },
  actionText: { color: '#ffffff', fontSize: 11, fontWeight: '800' },
  rowLoader: { marginTop: 7 },
  completeBox: { marginTop: 8, padding: 13, borderRadius: 9, backgroundColor: '#dcfce7' },
  pendingBox: { marginTop: 8, padding: 13, borderRadius: 9, backgroundColor: '#fff7ed' },
  completeText: { color: '#15803d', textAlign: 'center', fontWeight: '800' },
  pendingText: { color: '#b45309', textAlign: 'center', fontWeight: '700' },
  continueButton: { marginTop: 14, backgroundColor: '#16a34a', borderRadius: 10, paddingVertical: 15, alignItems: 'center' },
  disabledButton: { backgroundColor: '#9ca3af' },
  continueText: { color: '#ffffff', fontSize: 16, fontWeight: '800' },
  backButton: { marginTop: 12, borderWidth: 1, borderColor: '#d1d5db', borderRadius: 9, paddingVertical: 13, alignItems: 'center' },
  backText: { color: '#374151', fontWeight: '700' },
});
