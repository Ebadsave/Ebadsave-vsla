import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useRoute } from '@react-navigation/native';
import {
  closeMeeting,
  createFinancialCollection,
  getGroupById,
  getMembersByGroupId,
  getOpenMeeting,
  getVSLASetupRules,
} from '../database/database';

interface RouteParams {
  groupId?: number;
  meetingId?: number | null;
  executiveMemberId?: number | null;
  currency?: string;
}

interface MemberItem {
  id: number;
  member_number: string;
  full_name: string;
  status: string;
}

interface SetupRules {
  share_value: number;
  minimum_shares_per_meeting: number;
  maximum_shares_per_meeting: number;
}

const FINE_TYPES = [
  'Absence fine',
  'Late fine',
  'Non-saving fine',
  'Non-loan repayment fine',
  'Non-insurance contribution fine',
];

function money(value: number): string {
  return Number(value || 0).toLocaleString();
}

function numberFromText(value: string): number {
  const parsed = Number(value.replace(/,/g, '').trim());
  return Number.isFinite(parsed) ? parsed : 0;
}

export default function FinancialTransactionsScreen() {
  const route = useRoute();
  const params = (route.params ?? {}) as RouteParams;

  const groupId = Number(params.groupId ?? 0);
  const suppliedMeetingId =
    params.meetingId == null ? null : Number(params.meetingId);
  const suppliedExecutiveId =
    params.executiveMemberId == null
      ? null
      : Number(params.executiveMemberId);

  const [meetingId, setMeetingId] = useState<number | null>(suppliedMeetingId);
  const [executiveMemberId, setExecutiveMemberId] =
    useState<number | null>(suppliedExecutiveId);
  const [currency, setCurrency] = useState(params.currency?.trim() || 'UGX');

  const [members, setMembers] = useState<MemberItem[]>([]);
  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  const [rules, setRules] = useState<SetupRules>({
    share_value: 1000,
    minimum_shares_per_meeting: 1,
    maximum_shares_per_meeting: 100,
  });

  const [sharesPurchased, setSharesPurchased] = useState('');
  const [loanRepayment, setLoanRepayment] = useState('');
  const [fineType, setFineType] = useState(FINE_TYPES[0]);
  const [fineAmount, setFineAmount] = useState('');
  const [socialFund, setSocialFund] = useState('');
  const [insurance, setInsurance] = useState('');
  const [showFineTypes, setShowFineTypes] = useState(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [closing, setClosing] = useState(false);

  const loadData = useCallback(async () => {
    if (!groupId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      let activeMeetingId = suppliedMeetingId;
      if (activeMeetingId === null) {
        const openMeeting = await getOpenMeeting(groupId);
        activeMeetingId = openMeeting?.id ?? null;

        if (activeMeetingId !== null && suppliedExecutiveId === null) {
          // The meeting itself does not store the executive id, so keep the
          // supplied route value when available. Closing requires that id.
        }
      }
      setMeetingId(activeMeetingId);

      const [group, memberRows, setup] = await Promise.all([
        getGroupById(groupId),
        getMembersByGroupId(groupId),
        getVSLASetupRules(groupId),
      ]);

      if (group?.currency?.trim()) {
        setCurrency(group.currency.trim());
      }

      if (setup) {
        setRules({
          share_value: Number(setup.share_value) || 1000,
          minimum_shares_per_meeting:
            Number(setup.minimum_shares_per_meeting) || 1,
          maximum_shares_per_meeting:
            Number(setup.maximum_shares_per_meeting) || 100,
        });
      }

      const activeMembers = (memberRows as MemberItem[])
        .filter((member) => member.status?.toLowerCase() === 'active')
        .sort((a, b) =>
          a.full_name.localeCompare(b.full_name, undefined, {
            sensitivity: 'base',
          }),
        );

      setMembers(activeMembers);

      if (
        selectedMemberId === null ||
        !activeMembers.some((member) => member.id === selectedMemberId)
      ) {
        setSelectedMemberId(activeMembers[0]?.id ?? null);
      }
    } catch (error) {
      Alert.alert(
        'Financial Transactions',
        error instanceof Error ? error.message : 'Unable to load meeting data.',
      );
    } finally {
      setLoading(false);
    }
  }, [groupId, selectedMemberId, suppliedMeetingId, suppliedExecutiveId]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const selectedMember = useMemo(
    () => members.find((member) => member.id === selectedMemberId) ?? null,
    [members, selectedMemberId],
  );

  const savingsAmount =
    Math.max(0, Math.floor(numberFromText(sharesPurchased))) * rules.share_value;
  const loanAmount = numberFromText(loanRepayment);
  const fine = numberFromText(fineAmount);
  const social = numberFromText(socialFund);
  const insuranceAmount = numberFromText(insurance);
  const totalPayment =
    savingsAmount + loanAmount + fine + social + insuranceAmount;

  const clearCurrentForm = () => {
    setSharesPurchased('');
    setLoanRepayment('');
    setFineAmount('');
    setSocialFund('');
    setInsurance('');
  };

  const goToNextMember = () => {
    if (members.length === 0 || selectedMemberId === null) return;

    const currentIndex = members.findIndex(
      (member) => member.id === selectedMemberId,
    );
    const nextIndex = currentIndex + 1;

    if (nextIndex >= members.length) {
      Alert.alert(
        'End of member list',
        'All active members in A–Z order have been processed.',
      );
      return;
    }

    setSelectedMemberId(members[nextIndex].id);
    clearCurrentForm();
  };

  const recordTransaction = async () => {
    if (!meetingId) {
      Alert.alert('Meeting not started', 'Start the meeting before recording transactions.');
      return;
    }

    if (!selectedMemberId) {
      Alert.alert('Member required', 'Select the member making this payment.');
      return;
    }

    const shares = Math.floor(numberFromText(sharesPurchased));

    if (shares > 0) {
      if (shares < rules.minimum_shares_per_meeting) {
        Alert.alert(
          'Minimum savings not met',
          `Minimum savings is ${rules.minimum_shares_per_meeting} share(s).`,
        );
        return;
      }

      if (shares > rules.maximum_shares_per_meeting) {
        Alert.alert(
          'Maximum savings exceeded',
          `Maximum savings is ${rules.maximum_shares_per_meeting} share(s).`,
        );
        return;
      }
    }

    if (totalPayment <= 0) {
      Alert.alert('No payment', 'Enter at least one financial amount.');
      return;
    }

    setSaving(true);
    try {
      const payments: Array<{
        accountType:
          | 'savings'
          | 'loan_repayment'
          | 'fines'
          | 'social_fund'
          | 'insurance_fund';
        amount: number;
        reason: string;
      }> = [];

      if (savingsAmount > 0) {
        payments.push({
          accountType: 'savings',
          amount: savingsAmount,
          reason: `${shares} share(s) purchased`,
        });
      }

      if (loanAmount > 0) {
        payments.push({
          accountType: 'loan_repayment',
          amount: loanAmount,
          reason: 'Loan repayment',
        });
      }

      if (fine > 0) {
        payments.push({
          accountType: 'fines',
          amount: fine,
          reason: fineType,
        });
      }

      if (social > 0) {
        payments.push({
          accountType: 'social_fund',
          amount: social,
          reason: 'Social fund contribution',
        });
      }

      if (insuranceAmount > 0) {
        payments.push({
          accountType: 'insurance_fund',
          amount: insuranceAmount,
          reason: 'Insurance contribution',
        });
      }

      await createFinancialCollection(
        groupId,
        selectedMemberId,
        meetingId,
        payments,
      );

      const memberName = selectedMember?.full_name ?? 'Member';
      clearCurrentForm();

      Alert.alert(
        'Financial transaction recorded',
        `${memberName}: ${currency} ${money(totalPayment)}`,
      );
    } catch (error) {
      Alert.alert(
        'Transaction failed',
        error instanceof Error
          ? error.message
          : 'Unable to record the financial transaction.',
      );
    } finally {
      setSaving(false);
    }
  };

  const concludeMeeting = async () => {
    if (!meetingId) return;

    if (!executiveMemberId) {
      Alert.alert(
        'Executive required',
        'The meeting was not opened with an executive member ID. Return to the meeting screen and start it again so the meeting can be concluded correctly.',
      );
      return;
    }

    Alert.alert(
      'Conclude meeting',
      'Are you sure you want to conclude this meeting? No more transactions can be recorded after it is closed.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Conclude',
          style: 'destructive',
          onPress: async () => {
            setClosing(true);
            try {
              await closeMeeting(meetingId, executiveMemberId);
              Alert.alert('Meeting concluded', 'The meeting has been recorded as closed.');
            } catch (error) {
              Alert.alert(
                'Unable to conclude meeting',
                error instanceof Error ? error.message : 'The meeting could not be closed.',
              );
            } finally {
              setClosing(false);
            }
          },
        },
      ],
    );
  };

  if (!groupId || loading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#16a34a" />
          <Text style={styles.loadingText}>
            {!groupId ? 'Group information is missing.' : 'Loading financial transaction...'}
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!meetingId) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.centered}>
          <Text style={styles.title}>Financial Transactions</Text>
          <Text style={styles.emptyText}>Start a meeting before recording payments.</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Financial Transactions</Text>
          <Text style={styles.headerSubtitle}>Meeting #{meetingId}</Text>
        </View>

        <View style={styles.memberCard}>
          <Text style={styles.memberLabel}>Current member</Text>
          <Text style={styles.memberName}>
            {selectedMember?.full_name ?? 'No active member'}
          </Text>
          <Text style={styles.memberNumber}>
            {selectedMember?.member_number ?? ''}
          </Text>
          <Text style={styles.azText}>
            A–Z order • {members.length === 0 ? 0 : members.findIndex((m) => m.id === selectedMemberId) + 1} of {members.length}
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>1. SAVINGS</Text>

          <Text style={styles.label}>Shares purchased</Text>
          <TextInput
            value={sharesPurchased}
            onChangeText={setSharesPurchased}
            keyboardType="number-pad"
            placeholder="0"
            placeholderTextColor="#9ca3af"
            style={styles.input}
          />

          <View style={styles.readOnlyRow}>
            <Text style={styles.readOnlyLabel}>Share value</Text>
            <Text style={styles.readOnlyValue}>
              {currency} {money(rules.share_value)}
            </Text>
          </View>

          <View style={styles.readOnlyRow}>
            <Text style={styles.readOnlyLabel}>Savings amount</Text>
            <Text style={styles.autoValue}>
              {currency} {money(savingsAmount)}
            </Text>
          </View>

          <Text style={styles.ruleText}>
            Allowed: {rules.minimum_shares_per_meeting}–{rules.maximum_shares_per_meeting} shares per meeting
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>2. LOAN REPAYMENT</Text>
          <Text style={styles.label}>Amount ({currency})</Text>
          <TextInput
            value={loanRepayment}
            onChangeText={setLoanRepayment}
            keyboardType="decimal-pad"
            placeholder="0"
            placeholderTextColor="#9ca3af"
            style={styles.input}
          />
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>3. FINES</Text>
          <Text style={styles.label}>Fine type</Text>
          <TouchableOpacity
            style={styles.selector}
            onPress={() => setShowFineTypes((value) => !value)}
          >
            <Text style={styles.selectorText}>{fineType}</Text>
            <Text>{showFineTypes ? '▲' : '▼'}</Text>
          </TouchableOpacity>

          {showFineTypes && (
            <View style={styles.optionsBox}>
              {FINE_TYPES.map((item) => (
                <TouchableOpacity
                  key={item}
                  style={styles.option}
                  onPress={() => {
                    setFineType(item);
                    setShowFineTypes(false);
                  }}
                >
                  <Text style={styles.optionText}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <Text style={styles.label}>Amount ({currency})</Text>
          <TextInput
            value={fineAmount}
            onChangeText={setFineAmount}
            keyboardType="decimal-pad"
            placeholder="0"
            placeholderTextColor="#9ca3af"
            style={styles.input}
          />
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>4. SOCIAL FUND</Text>
          <Text style={styles.label}>Amount ({currency})</Text>
          <TextInput
            value={socialFund}
            onChangeText={setSocialFund}
            keyboardType="decimal-pad"
            placeholder="0"
            placeholderTextColor="#9ca3af"
            style={styles.input}
          />
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>5. INSURANCE</Text>
          <Text style={styles.label}>Amount ({currency})</Text>
          <TextInput
            value={insurance}
            onChangeText={setInsurance}
            keyboardType="decimal-pad"
            placeholder="0"
            placeholderTextColor="#9ca3af"
            style={styles.input}
          />
        </View>

        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>TOTAL PAYMENT</Text>
          <Text style={styles.totalValue}>
            {currency} {money(totalPayment)}
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.recordButton, saving && styles.disabledButton]}
          onPress={recordTransaction}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <Text style={styles.recordButtonText}>RECORD FINANCIAL TRANSACTION</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.nextButton, members.length === 0 && styles.disabledButton]}
          onPress={goToNextMember}
          disabled={members.length === 0 || saving}
        >
          <Text style={styles.nextButtonText}>Next member → A–Z</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.concludeButton, closing && styles.disabledButton]}
          onPress={concludeMeeting}
          disabled={closing}
        >
          {closing ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <Text style={styles.concludeButtonText}>CONCLUDE MEETING</Text>
          )}
        </TouchableOpacity>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 18, gap: 10 }}>
          <TouchableOpacity style={[styles.navigationButton, { flex: 1 }]} onPress={() => navigation.canGoBack() && navigation.goBack()}>
            <Text style={styles.navigationButtonText}>Back</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.navigationButton, { flex: 1 }]} onPress={() => navigation.navigate('Expenditure', { groupId, meetingId })}>
            <Text style={styles.navigationButtonText}>Next</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#f5f7f6' },
  container: { padding: 16, paddingBottom: 40 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  loadingText: { marginTop: 10, color: '#6b7280', textAlign: 'center' },
  title: { fontSize: 24, fontWeight: '800', color: '#111827' },
  emptyText: { marginTop: 8, color: '#6b7280', textAlign: 'center' },
  header: { backgroundColor: '#16a34a', borderRadius: 14, padding: 18, marginBottom: 12 },
  headerTitle: { color: '#ffffff', fontSize: 23, fontWeight: '800' },
  headerSubtitle: { color: '#ffffff', marginTop: 4, opacity: 0.9 },
  memberCard: { backgroundColor: '#ffffff', borderRadius: 14, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#dcfce7' },
  memberLabel: { color: '#166534', fontSize: 12, fontWeight: '700' },
  memberName: { color: '#111827', fontSize: 20, fontWeight: '800', marginTop: 3 },
  memberNumber: { color: '#374151', marginTop: 3 },
  azText: { color: '#16a34a', marginTop: 7, fontWeight: '700' },
  card: { backgroundColor: '#ffffff', borderRadius: 14, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#e5e7eb' },
  sectionTitle: { color: '#166534', fontSize: 17, fontWeight: '800', marginBottom: 5 },
  label: { color: '#374151', fontSize: 14, fontWeight: '700', marginTop: 10, marginBottom: 7 },
  input: { minHeight: 50, borderWidth: 1, borderColor: '#d1d5db', borderRadius: 10, paddingHorizontal: 13, fontSize: 18, color: '#111827', backgroundColor: '#ffffff' },
  readOnlyRow: { minHeight: 50, borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 10, paddingHorizontal: 13, marginTop: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#f9fafb' },
  readOnlyLabel: { color: '#4b5563' },
  readOnlyValue: { color: '#111827', fontWeight: '700' },
  autoValue: { color: '#16a34a', fontSize: 18, fontWeight: '800' },
  ruleText: { color: '#6b7280', fontSize: 12, marginTop: 8 },
  selector: { minHeight: 50, borderWidth: 1, borderColor: '#d1d5db', borderRadius: 10, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  selectorText: { color: '#111827', flex: 1 },
  optionsBox: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 10, marginTop: 5, overflow: 'hidden' },
  option: { padding: 13, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  optionText: { color: '#111827' },
  totalCard: { backgroundColor: '#f0fdf4', borderRadius: 14, padding: 18, marginBottom: 12, borderWidth: 1, borderColor: '#bbf7d0' },
  totalLabel: { color: '#166534', fontSize: 13, fontWeight: '800' },
  totalValue: { color: '#15803d', fontSize: 25, fontWeight: '900', marginTop: 4 },
  recordButton: { minHeight: 54, backgroundColor: '#16a34a', borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  recordButtonText: { color: '#ffffff', fontSize: 15, fontWeight: '900' },
  nextButton: { minHeight: 52, backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#16a34a', borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  nextButtonText: { color: '#15803d', fontSize: 15, fontWeight: '800' },
  concludeButton: { minHeight: 52, backgroundColor: '#b91c1c', borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  concludeButtonText: { color: '#ffffff', fontSize: 15, fontWeight: '900' },
  disabledButton: { opacity: 0.55 },
});
