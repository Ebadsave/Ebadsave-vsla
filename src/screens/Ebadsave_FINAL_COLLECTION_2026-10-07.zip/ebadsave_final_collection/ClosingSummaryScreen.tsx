import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { closeMeeting, getMeetingCashReconciliation, getMeetingTransactionSummary, getGroupCurrency, getMembersByGroupId } from '../database/database';

export default function ClosingSummaryScreen({ navigation }: any) {
  const route = useRoute<any>();
  const { groupId, meetingId, executiveMemberId } = route.params || {};
  const [summary, setSummary] = useState<any>(null);
  const [currency, setCurrency] = useState('UGX');
  const [cash, setCash] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setCurrency(await getGroupCurrency(Number(groupId)));
      setSummary(await getMeetingTransactionSummary(Number(meetingId)));
    } catch (e) { Alert.alert('Closing Summary', e instanceof Error ? e.message : 'Unable to load summary.'); }
    finally { setLoading(false); }
  }, [groupId, meetingId]);
  useEffect(() => { void load(); }, [load]);

  const cashValue = Number(cash.replace(/,/g, '').trim());
  const reconciliation = useMemo(() => {
    if (!Number.isFinite(cashValue) || cashValue < 0 || !summary) return null;
    return Number(summary.loanFund ?? 0) + Number(summary.savings ?? 0) + Number(summary.fines ?? 0) + Number(summary.loanRepayment ?? 0) + Number(summary.socialFund ?? 0) + Number(summary.insuranceFund ?? 0) - Number(summary.loansGiven ?? 0) - Number(summary.miscellaneousExpense ?? 0);
  }, [cashValue, summary]);
  const difference = reconciliation === null ? null : Number((reconciliation - cashValue).toFixed(2));
  const balanced = difference !== null && Math.abs(difference) < 0.01;

  const finish = async () => {
    if (!confirmed || !balanced) return;
    try { await closeMeeting(Number(meetingId), Number(executiveMemberId), cashValue); Alert.alert('Meeting Closed', 'Closing summary confirmed and balanced.'); navigation.navigate('Home'); }
    catch (e) { Alert.alert('Cannot Close Meeting', e instanceof Error ? e.message : 'Unable to close meeting.'); }
  };

  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.content}>
    <Text style={styles.title}>Closing Summary</Text>
    {loading || !summary ? <Text>Loading…</Text> : <>
      {([['Opening Cash', Number(summary.loanFund ?? 0)],['Savings Today',Number(summary.savings ?? 0)],['Fines Collected',Number(summary.fines ?? 0)],['Loan Repayment',Number(summary.loanRepayment ?? 0)],['Loans Given',Number(summary.loansGiven ?? 0)],['Expenses',Number(summary.miscellaneousExpense ?? 0)]] as const).map(([label,value]) => <View style={styles.row} key={label}><Text>{label}</Text><Text style={styles.value}>{currency} {value.toLocaleString()}</Text></View>)}
      <View style={styles.total}><Text>Expected Cash at Hand</Text><Text style={styles.value}>{currency} {Number(reconciliation ?? 0).toLocaleString()}</Text></View>
      <Text style={styles.label}>Actual Cash Counted</Text><TextInput value={cash} onChangeText={setCash} keyboardType="numeric" placeholder="0" style={styles.input}/>
      <View style={styles.row}><Text>Difference</Text><Text style={[styles.value, difference !== null && !balanced && styles.red]}>{currency} {Number(difference ?? 0).toLocaleString()}</Text></View>
      <TouchableOpacity style={styles.checkRow} onPress={() => setConfirmed(v => !v)}><Text style={styles.check}>{confirmed ? '☑' : '☐'}</Text><Text>I confirm cash balances</Text></TouchableOpacity>
      {difference !== null && !balanced && <Text style={styles.red}>Cash does not balance. Recheck.</Text>}
      <TouchableOpacity style={[styles.close, (!confirmed || !balanced) && styles.disabled]} disabled={!confirmed || !balanced} onPress={finish}><Text style={styles.closeText}>CONFIRM & CLOSE MEETING</Text></TouchableOpacity>
    </>}
    <TouchableOpacity style={styles.back} onPress={() => navigation.canGoBack() && navigation.goBack()}><Text>Back</Text></TouchableOpacity>
  </ScrollView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#fff'},content:{padding:18,paddingBottom:40},title:{fontSize:26,fontWeight:'800',color:'#16a34a',marginBottom:18},row:{flexDirection:'row',justifyContent:'space-between',paddingVertical:12,borderBottomWidth:1,borderBottomColor:'#e5e7eb'},value:{fontWeight:'800'},total:{marginTop:12,padding:14,backgroundColor:'#f0fdf4',borderRadius:10,flexDirection:'row',justifyContent:'space-between'},label:{fontWeight:'700',marginTop:18,marginBottom:7},input:{borderWidth:1,borderColor:'#d1d5db',borderRadius:10,padding:14,fontSize:18},checkRow:{flexDirection:'row',alignItems:'center',gap:10,marginTop:18},check:{fontSize:26},close:{marginTop:20,backgroundColor:'#16a34a',padding:15,borderRadius:10,alignItems:'center'},disabled:{backgroundColor:'#9ca3af'},closeText:{color:'#fff',fontWeight:'800'},red:{color:'#dc2626',fontWeight:'800',marginTop:12},back:{marginTop:14,borderWidth:1,borderColor:'#d1d5db',padding:13,borderRadius:10,alignItems:'center'}});
